<?php
// Scan the videos directory for video files
 $videoDir = 'videos/';
 $videos = array_diff(scandir($videoDir), array('..', '.'));

// Include the header template
 include 'templates/header.php';
 ?>

 <div class="gallery">
     <?php foreach ($videos as $video): ?>
             <div class="video-item">
                         <video controls>
                                         <source src="<?= $videoDir . $video ?>" type="video/mp4">
                                                         Your browser does not support the video tag.
                                                                     </video>
                                                                                 <p><?= $video ?></p>
                                                                                         </div>
                                                                                             <?php endforeach; ?>
                                                                                             </div>

                                                                                            </body>
                                                                                             </html>

